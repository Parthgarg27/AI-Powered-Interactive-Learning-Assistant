"use client";

import React, { useState, useEffect, useRef } from "react";
import { useSession } from "next-auth/react";

interface Note {
  _id: string;
  title: string;
  content: string;
  createdBy: string;
  createdById: string;
  tags: string[];
  attachments: { filename: string; url: string; type: string }[];
  ratings: { userId: string; rating: number; createdAt: string }[];
  averageRating: number;
  comments: { userId: string; comment: string; createdAt: string }[];
  createdAt: string;
  updatedAt: string;
  files?: File[];
}

const NotesClient: React.FC = () => {
  const { data: session } = useSession();
  const [notes, setNotes] = useState<Note[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [newNote, setNewNote] = useState({ title: "", content: "", tags: "", files: [] as File[] });
  const [dragActive, setDragActive] = useState(false);
  const [rating, setRating] = useState<{ [key: string]: number }>({});
  const [comment, setComment] = useState<{ [key: string]: string }>({});
  const [error, setError] = useState<string | null>(null);
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [selectedAttachment, setSelectedAttachment] = useState<{ filename: string; url: string; type: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    console.log("Logged-in user ID:", session?.user?.id);
    const fetchNotes = async () => {
      try {
        console.log("Fetching notes from /api/tables...");
        const res = await fetch("/api/tables");
        if (!res.ok) {
          const text = await res.text();
          console.error("Fetch failed with status:", res.status, "Response:", text);
          throw new Error(`Failed to fetch notes: ${res.status} ${text}`);
        }
        const data = await res.json();
        console.log("Fetched notes:", data);
        setNotes(data);
      } catch (err: any) {
        setError("Error fetching notes: " + err.message);
        console.error("Error in fetchNotes:", err);
      }
    };
    fetchNotes();
  }, []);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files) {
      const newFiles = Array.from(e.dataTransfer.files);
      if (newNote.files.length + newFiles.length > 5) {
        setError("Maximum 5 attachments allowed.");
        return;
      }
      setNewNote({ ...newNote, files: [...newNote.files, ...newFiles] });
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      if (newNote.files.length + newFiles.length > 5) {
        setError("Maximum 5 attachments allowed.");
        return;
      }
      setNewNote({ ...newNote, files: [...newNote.files, ...newFiles] });
    }
  };

  const removeFile = (index: number) => {
    setNewNote({ ...newNote, files: newNote.files.filter((_, i) => i !== index) });
  };

  const handleUpload = async () => {
    if (!session?.user) {
      setError("You must be logged in to upload notes.");
      return;
    }
    const formData = new FormData();
    formData.append("title", newNote.title);
    formData.append("content", newNote.content);
    formData.append("tags", newNote.tags);
    newNote.files.forEach((file) => formData.append("files", file));

    try {
      const res = await fetch("/api/tables", {
        method: "POST",
        body: formData,
      });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to upload note");
      }
      const data = await res.json();
      setNotes([...notes, data]);
      setNewNote({ title: "", content: "", tags: "", files: [] });
      setError(null);
    } catch (err: any) {
      setError(err.message || "Error uploading note. Please try again.");
      console.error(err);
    }
  };

  const handleUpdate = async (noteId: string) => {
    if (!selectedNote) return;
    
    const confirmUpdate = window.confirm("Are you sure you want to update this note?");
    if (!confirmUpdate) return;
    
    const noteToUpdate = notes.find((note) => note._id === noteId);
    console.log("Checking authorization on frontend:", {
      noteId,
      sessionUserId: session?.user?.id,
      noteCreatedById: noteToUpdate?.createdById,
      isMatch: session?.user?.id === noteToUpdate?.createdById,
      fullSession: session,
    });
  
    if (!noteToUpdate || noteToUpdate.createdById !== session?.user?.id) {
      console.log("Update prevented: User ID mismatch or note not found", {
        noteId,
        userId: session?.user?.id,
        createdById: noteToUpdate?.createdById,
      });
      setError("You are not authorized to edit this note or note not found.");
      return;
    }
  
    const formData = new FormData();
    formData.append("title", selectedNote.title);
    formData.append("content", selectedNote.content);
    formData.append("tags", selectedNote.tags.join(","));
    if (selectedNote.files && selectedNote.files.length > 0) {
      selectedNote.files.forEach((file) => formData.append("files", file));
    }
  
    try {
      const res = await fetch(`/api/tables/${noteId}`, {
        method: "PUT",
        body: formData,
      });
    
      if (!res.ok) {
        const errorText = await res.text();
        let errorMessage = `Failed to update note: ${res.status}`;
        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.message || errorMessage;
          if (errorData.details) {
            errorMessage += ` - ${errorData.details}`;
          }
        } catch (jsonError) {
          console.error("PUT request failed:", {
            status: res.status,
            statusText: res.statusText,
            response: errorText,
          });
          errorMessage += ` - ${errorText}`;
        }
        throw new Error(errorMessage);
      }
    
      const updatedNote = await res.json();
      console.log("Updated note from backend:", updatedNote);
      setNotes(notes.map((note) => (note._id === noteId ? updatedNote : note)));
      setSelectedNote(null);
      setError(null);
    } catch (err: any) {
      setError(err.message || "Error updating note. Please try again.");
      console.error("Error in handleUpdate:", err);
    }
  };

  const handleDelete = async (noteId: string) => {
    const noteToDelete = notes.find((note) => note._id === noteId);
    if (!noteToDelete || noteToDelete.createdById !== session?.user?.id) {
      console.log("Delete prevented: User ID mismatch or note not found", {
        noteId,
        userId: session?.user?.id,
        createdById: noteToDelete?.createdById,
      });
      return;
    }

    const confirmDelete = window.confirm("Are you sure you want to delete this note?");
    if (!confirmDelete) return;

    try {
      const res = await fetch(`/api/tables/${noteId}`, {
        method: "DELETE",
      });
      if (!res.ok) {
        let errorMessage = `Failed to delete note: ${res.status}`;
        try {
          const errorData = await res.json();
          errorMessage = errorData.message || errorMessage;
        } catch (jsonError) {
          const text = await res.text();
          errorMessage = text || errorMessage;
        }
        console.error("DELETE request failed:", {
          status: res.status,
          statusText: res.statusText,
          response: errorMessage,
        });
        throw new Error(errorMessage);
      }
      setNotes(notes.filter((note) => note._id !== noteId));
      setSelectedNote(null);
      setError(null);
    } catch (err: any) {
      setError(err.message || "Error deleting note. Please try again.");
      console.error("Error in handleDelete:", err);
    }
  };

  const handleDeleteAttachment = async (noteId: string, attachmentIndex: number) => {
    if (!selectedNote || selectedNote.createdById !== session?.user?.id) {
      console.log("Delete attachment prevented: User ID mismatch or note not found", {
        noteId,
        userId: session?.user?.id,
        createdById: selectedNote?.createdById,
      });
      return;
    }

    const confirmDelete = window.confirm("Are you sure you want to delete this attachment?");
    if (!confirmDelete) return;

    try {
      const res = await fetch(`/api/tables/${noteId}/attachments/${attachmentIndex}`, {
        method: "DELETE",
      });
      if (!res.ok) {
        let errorMessage = `Failed to delete attachment: ${res.status}`;
        try {
          const errorData = await res.json();
          errorMessage = errorData.message || errorMessage;
        } catch (jsonError) {
          const text = await res.text();
          errorMessage = text || errorMessage;
        }
        console.error("DELETE attachment request failed:", {
          status: res.status,
          statusText: res.statusText,
          response: errorMessage,
        });
        throw new Error(errorMessage);
      }
      const updatedNote = await res.json();
      setNotes(notes.map((note) => (note._id === noteId ? updatedNote : note)));
      setSelectedNote({ ...updatedNote, files: selectedNote.files || [] });
      setError(null);
    } catch (err: any) {
      setError(err.message || "Error deleting attachment. Please try again.");
      console.error("Error in handleDeleteAttachment:", err);
    }
  };

  const handleRate = async (noteId: string, value: number) => {
    if (value < 1 || value > 5) {
      setError("Please select a rating between 1 and 5.");
      return;
    }
    try {
      console.log("Attempting to rate note:", { noteId, rating: value });
      const url = `/api/tables/${noteId}/rate`;
      console.log("Fetching URL:", url);
      const res = await fetch(url, {
        method: "POST",
        body: JSON.stringify({ rating: value }),
        headers: { "Content-Type": "application/json" },
      });
      if (!res.ok) {
        const errorData = await res.text();
        console.error("Rating request failed:", {
          status: res.status,
          statusText: res.statusText,
          response: errorData,
        });
        throw new Error(`Failed to rate note: ${res.status} ${errorData}`);
      }
      const updatedNote = await res.json();
      console.log("Rating successful, updated note:", updatedNote);
      setNotes(notes.map((note) => (note._id === noteId ? updatedNote : note)));
      setRating({ ...rating, [noteId]: value });
      setError(null);
    } catch (err) {
      setError("Error rating note. Please try again.");
      console.error("Error in handleRate:", err);
    }
  };

  const handleComment = async (noteId: string) => {
    const newComment = comment[noteId] || "";
    if (!newComment.trim()) {
      setError("Comment cannot be empty.");
      return;
    }
    try {
      console.log("Attempting to add comment to note:", { noteId, comment: newComment });
      const url = `/api/tables/${noteId}/comment`;
      console.log("Fetching URL:", url);
      const res = await fetch(url, {
        method: "POST",
        body: JSON.stringify({ comment: newComment }),
        headers: { "Content-Type": "application/json" },
      });
      if (!res.ok) {
        const errorData = await res.text();
        console.error("Comment request failed:", {
          status: res.status,
          statusText: res.statusText,
          response: errorData,
        });
        throw new Error(`Failed to add comment: ${res.status} ${errorData}`);
      }
      const updatedNote = await res.json();
      console.log("Comment added successfully, updated note:", updatedNote);
      setNotes(notes.map((note) => (note._id === noteId ? updatedNote : note)));
      setComment({ ...comment, [noteId]: "" });
      setError(null);
    } catch (err) {
      setError("Error adding comment. Please try again.");
      console.error("Error in handleComment:", err);
    }
  };

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      setSelectedNote(null);
      setSelectedAttachment(null);
    }
  };

  const handleAttachmentClick = (attachment: { filename: string; url: string; type: string }) => {
    setSelectedAttachment(attachment);
  };

  const renderAttachmentPreview = (attachment: { filename: string; url: string; type: string }) => {
    const type = attachment.type.toLowerCase();
    if (type.startsWith("image/")) {
      return <img src={attachment.url} alt={attachment.filename} className="max-w-full max-h-[60vh] object-contain" />;
    } else if (type === "application/pdf") {
      return (
        <iframe
          src={attachment.url}
          className="w-full h-[60vh]"
          title={attachment.filename}
        />
      );
    } else {
      return <p className="text-gray-300">Preview not available for this file type.</p>;
    }
  };

  const filteredNotes = notes.filter((note) => {
    const query = searchQuery.toLowerCase();
    const uploaderMatch = note.createdBy.toLowerCase().includes(query);
    const subjectMatch = note.tags.some((tag) => tag.toLowerCase().includes(query));
    const titleMatch = note.title.toLowerCase().includes(query);
    return uploaderMatch || subjectMatch || titleMatch;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-gray-100 p-6 md:p-8 animate-fade-in">
      {error && (
        <div className="mb-6 p-4 bg-red-600/80 backdrop-blur-sm rounded-xl shadow-lg border border-red-500/50 animate-slide-down">
          <p className="text-sm font-medium">{error}</p>
        </div>
      )}

      {session?.user && (
        <div className="mb-8 p-6 bg-gray-800/80 backdrop-blur-sm rounded-xl shadow-xl border border-gray-700/50 animate-slide-up">
          <h2 className="text-2xl md:text-3xl font-bold mb-6 text-blue-300">Upload a New Note</h2>
          <div className="space-y-4">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-300 mb-1">
                Title
              </label>
              <input
                type="text"
                id="title"
                placeholder="Enter note title"
                value={newNote.title}
                onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
                className="w-full p-3 bg-gray-700/50 border border-gray-600 rounded-lg text-gray-100 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              />
            </div>
            <div>
              <label htmlFor="content" className="block text-sm font-medium text-gray-300 mb-1">
                Content
              </label>
              <textarea
                id="content"
                placeholder="Write your note content here..."
                value={newNote.content}
                onChange={(e) => setNewNote({ ...newNote, content: e.target.value })}
                className="w-full p-3 bg-gray-700/50 border border-gray-600 rounded-lg text-gray-100 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all h-32 resize-y"
              />
            </div>
            <div>
              <label htmlFor="tags" className="block text-sm font-medium text-gray-300 mb-1">
                Tags (comma-separated)
              </label>
              <input
                type="text"
                id="tags"
                placeholder="e.g., math, physics, study"
                value={newNote.tags}
                onChange={(e) => setNewNote({ ...newNote, tags: e.target.value })}
                className="w-full p-3 bg-gray-700/50 border border-gray-600 rounded-lg text-gray-100 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              />
            </div>
            <div
              className={`border-2 border-dashed p-6 rounded-lg text-center transition-all ${
                dragActive
                  ? "border-blue-500 bg-gray-600/50 scale-105"
                  : "border-gray-500 hover:border-gray-400"
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <p className="text-gray-300">Drag and drop your files here or</p>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
                id="file-upload"
                multiple
              />
              <label
                htmlFor="file-upload"
                className="text-blue-400 hover:text-blue-300 cursor-pointer transition-colors"
              >
                click to upload
              </label>
              {newNote.files.length > 0 && (
                <div className="mt-2 text-sm text-gray-400">
                  <p>Selected files:</p>
                  <ul className="list-disc list-inside">
                    {newNote.files.map((file, index) => (
                      <li key={index} className="flex items-center justify-between">
                        {file.name}
                        <button
                          onClick={() => removeFile(index)}
                          className="text-red-400 hover:text-red-300 ml-2"
                        >
                          <svg
                            className="w-4 h-4"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth="2"
                              d="M6 18L18 6M6 6l12 12"
                            />
                          </svg>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            <button
              onClick={handleUpload}
              className="w-full md:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg text-white font-medium shadow-md hover:shadow-lg hover:scale-105 transition-all duration-300"
            >
              Upload Note
            </button>
          </div>
        </div>
      )}

      <div className="mb-8 p-6 bg-gray-800/80 backdrop-blur-sm rounded-xl shadow-xl border border-gray-700/50 animate-slide-up">
        <h2 className="text-2xl md:text-3xl font-bold mb-6 text-blue-300">Search Notes</h2>
        <div className="relative">
          <input
            type="text"
            placeholder="Search by title, uploader, or subject/tag..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full p-3 pl-10 bg-gray-700/50 border border-gray-600 rounded-lg text-gray-100 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          />
          <svg
            className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredNotes.length === 0 ? (
          <p className="col-span-full text-center text-gray-400 text-lg animate-fade-in">
            No notes found. Try adjusting your search criteria.
          </p>
        ) : (
          filteredNotes.map((note, index) => (
            <div
              key={note._id}
              className="relative p-5 bg-gray-800/80 backdrop-blur-sm rounded-xl shadow-xl border border-gray-700/50 hover:shadow-2xl hover:scale-105 transition-all duration-300 animate-card"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div onClick={() => setSelectedNote({ ...note, files: [] })} className="cursor-pointer">
                <h3 className="text-lg font-semibold text-blue-200 mb-2 truncate">{note.title}</h3>
                <p className="text-sm text-gray-400 mb-2">
                  <span className="font-medium">Uploaded by:</span> {note.createdBy}
                </p>
                <p className="text-sm text-gray-400 mb-2">
                  <span className="font-medium">Tags:</span>{" "}
                  <span className="truncate">{note.tags.join(", ")}</span>
                </p>
                <p className="text-sm text-gray-400">
                  <span className="font-medium">Rating:</span> {note.averageRating}/5
                </p>
              </div>

              {(() => {
                console.log("Rendering note buttons:", {
                  noteId: note._id,
                  sessionUserId: session?.user?.id,
                  noteCreatedById: note.createdById,
                  isMatch: session?.user?.id === note.createdById,
                });
                return session?.user?.id === note.createdById ? (
                  <div className="absolute top-3 right-3 flex gap-2">
                    <button
                      onClick={() => setSelectedNote({ ...note, files: [] })}
                      className="text-green-400 hover:text-green-300 transition-colors"
                      title="Edit Note"
                    >
                      <svg
                        className="w-5 h-5"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.536L16.732 3.732z"
                        />
                      </svg>
                    </button>
                    <button
                      onClick={() => handleDelete(note._id)}
                      className="text-red-400 hover:text-red-300 transition-colors"
                      title="Delete Note"
                    >
                      <svg
                        className="w-5 h-5"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5-4h4M9 7v12m6-12v12M3 7h18"
                        />
                      </svg>
                    </button>
                  </div>
                ) : null;
              })()}
            </div>
          ))
        )}
      </div>

      {selectedNote && (
        <div
          className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-modal-backdrop"
          onClick={handleBackdropClick}
        >
          <div className="bg-gray-800/90 backdrop-blur-sm rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto border border-gray-700/50 animate-modal-content">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-blue-200">Edit Note</h3>
                <button
                  onClick={() => setSelectedNote(null)}
                  className="text-gray-400 hover:text-gray-200 hover:scale-110 transition-all duration-300"
                >
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>

              <div className="space-y-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">Title</label>
                  <input
                    type="text"
                    value={selectedNote.title}
                    onChange={(e) =>
                      setSelectedNote({ ...selectedNote, title: e.target.value })
                    }
                    className="w-full p-3 bg-gray-700/50 border border-gray-600 rounded-lg text-gray-100 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">Content</label>
                  <textarea
                    value={selectedNote.content}
                    onChange={(e) =>
                      setSelectedNote({ ...selectedNote, content: e.target.value })
                    }
                    className="w-full p-3 bg-gray-700/50 border border-gray-600 rounded-lg text-gray-100 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all h-32 resize-y"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">Tags (comma-separated)</label>
                  <input
                    type="text"
                    value={selectedNote.tags.join(", ")}
                    onChange={(e) =>
                      setSelectedNote({
                        ...selectedNote,
                        tags: e.target.value.split(",").map((tag) => tag.trim()),
                      })
                    }
                    className="w-full p-3 bg-gray-700/50 border border-gray-600 rounded-lg text-gray-100 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                  />
                </div>
                {session?.user?.id === selectedNote.createdById && (
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">
                      Add New Attachments (Max 5 Total)
                    </label>
                    <div
                      className={`border-2 border-dashed p-6 rounded-lg text-center transition-all ${
                        dragActive
                          ? "border-blue-500 bg-gray-600/50 scale-105"
                          : "border-gray-500 hover:border-gray-400"
                      }`}
                      onDragEnter={handleDrag}
                      onDragLeave={handleDrag}
                      onDragOver={handleDrag}
                      onDrop={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setDragActive(false);
                        if (e.dataTransfer.files) {
                          const newFiles = Array.from(e.dataTransfer.files);
                          if ((selectedNote.attachments?.length || 0) + (selectedNote.files?.length || 0) + newFiles.length > 5) {
                            setError("Maximum 5 attachments allowed.");
                            return;
                          }
                          setSelectedNote({ ...selectedNote, files: [...(selectedNote.files || []), ...newFiles] });
                        }
                      }}
                    >
                      <p className="text-gray-300">Drag and drop your files here or</p>
                      <input
                        type="file"
                        ref={fileInputRef}
                        onChange={(e) => {
                          if (e.target.files) {
                            const newFiles = Array.from(e.target.files);
                            if ((selectedNote.attachments?.length || 0) + (selectedNote.files?.length || 0) + newFiles.length > 5) {
                              setError("Maximum 5 attachments allowed.");
                              return;
                            }
                            setSelectedNote({ ...selectedNote, files: [...(selectedNote.files || []), ...newFiles] });
                          }
                        }}
                        className="hidden"
                        id="file-upload-edit"
                        multiple
                      />
                      <label
                        htmlFor="file-upload-edit"
                        className="text-blue-400 hover:text-blue-300 cursor-pointer transition-colors"
                      >
                        click to upload
                      </label>
                      {selectedNote.files && selectedNote.files.length > 0 && (
                        <div className="mt-2 text-sm text-gray-400">
                          <p>Selected files:</p>
                          <ul className="list-disc list-inside">
                            {selectedNote.files.map((file, index) => (
                              <li key={index} className="flex items-center justify-between">
                                {file.name}
                                <button
                                  onClick={() =>
                                    setSelectedNote({
                                      ...selectedNote,
                                      files: selectedNote.files?.filter((_, i) => i !== index) || [],
                                    })
                                  }
                                  className="text-red-400 hover:text-red-300 ml-2"
                                >
                                  <svg
                                    className="w-4 h-4"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                    xmlns="http://www.w3.org/2000/svg"
                                  >
                                    <path
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                      strokeWidth="2"
                                      d="M6 18L18 6M6 6l12 12"
                                    />
                                  </svg>
                                </button>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {session?.user?.id === selectedNote.createdById && (
                <button
                  onClick={() => handleUpdate(selectedNote._id)}
                  className="mb-4 px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg text-white font-medium shadow-md hover:shadow-lg hover:scale-105 transition-all duration-300"
                >
                  Save Changes
                </button>
              )}

              <p className="text-sm text-gray-400 mb-2">
                <span className="font-medium">Uploaded by:</span> {selectedNote.createdBy}
              </p>
              <p className="text-sm text-gray-400 mb-4">
                <span className="font-medium">Average Rating:</span> {selectedNote.averageRating}/5
              </p>
              {selectedNote.attachments.length > 0 && (
                <div className="mb-4">
                  <h4 className="text-md font-medium text-gray-200 mb-2">Attachments:</h4>
                  <div className="space-y-2">
                    {selectedNote.attachments.map((attachment, idx) => (
                      <div key={idx} className="flex items-center justify-between">
                        <button
                          onClick={() => handleAttachmentClick(attachment)}
                          className="text-blue-400 hover:text-blue-300 underline transition-colors"
                        >
                          {attachment.filename}
                        </button>
                        {session?.user?.id === selectedNote.createdById && (
                          <button
                            onClick={() => handleDeleteAttachment(selectedNote._id, idx)}
                            className="text-red-400 hover:text-red-300 ml-2"
                            title="Delete Attachment"
                          >
                            <svg
                              className="w-4 h-4"
                              fill="none"
                              stroke="currentColor"
                              viewBox="0 0 24 24"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth="2"
                                d="M6 18L18 6M6 6l12 12"
                              />
                            </svg>
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {session?.user && (
                <div className="mb-4">
                  <label className="text-sm font-medium text-gray-300 mr-2">
                    Rate this note:
                  </label>
                  <select
                    value={rating[selectedNote._id] || ""}
                    onChange={(e) => {
                      console.log("Rating selected:", e.target.value);
                      handleRate(selectedNote._id, Number(e.target.value));
                    }}
                    className="p-2 bg-gray-700/50 border border-gray-600 rounded-lg text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                  >
                    <option value="" disabled>Select</option>
                    {[1, 2, 3, 4, 5].map((val) => (
                      <option key={val} value={val}>{val}</option>
                    ))}
                  </select>
                </div>
              )}

              <div className="mb-4">
                <h4 className="text-md font-medium text-gray-200 mb-2">Comments:</h4>
                {selectedNote.comments.length === 0 ? (
                  <p className="text-sm text-gray-400">No comments yet.</p>
                ) : (
                  <div className="space-y-2">
                    {selectedNote.comments.map((c, idx) => (
                      <p key={idx} className="text-sm text-gray-300 bg-gray-700/30 p-2 rounded-lg">
                        {c.comment}{" "}
                        <span className="text-gray-500">
                          - {new Date(c.createdAt).toLocaleDateString()}
                        </span>
                      </p>
                    ))}
                  </div>
                )}
                {session?.user && (
                  <div className="mt-4">
                    <textarea
                      placeholder="Add a comment..."
                      value={comment[selectedNote._id] || ""}
                      onChange={(e) => {
                        console.log("Comment input changed:", e.target.value);
                        setComment({ ...comment, [selectedNote._id]: e.target.value });
                      }}
                      className="w-full p-3 bg-gray-700/50 border border-gray-600 rounded-lg text-gray-100 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all h-20 resize-y"
                    />
                    <button
                      onClick={() => {
                        console.log("Post Comment button clicked for note:", selectedNote._id);
                        handleComment(selectedNote._id);
                      }}
                      className="mt-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white font-medium shadow-md hover:shadow-lg hover:scale-105 transition-all duration-300"
                    >
                      Post Comment
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {selectedAttachment && (
        <div
          className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-modal-backdrop"
          onClick={handleBackdropClick}
        >
          <div className="bg-gray-800/90 backdrop-blur-sm rounded-xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto border border-gray-700/50 animate-modal-content">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-blue-200">{selectedAttachment.filename}</h3>
                <button
                  onClick={() => setSelectedAttachment(null)}
                  className="text-gray-400 hover:text-gray-200 hover:scale-110 transition-all duration-300"
                >
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>
              <div className="mb-4 flex justify-center">
                {renderAttachmentPreview(selectedAttachment)}
              </div>
              <a
                href={selectedAttachment.url}
                download
                className="inline-block px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white font-medium shadow-md hover:shadow-lg hover:scale-105 transition-all duration-300"
              >
                Download
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NotesClient;