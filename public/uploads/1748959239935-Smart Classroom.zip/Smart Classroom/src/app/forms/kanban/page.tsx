"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { DragDropContext, DropResult, DragStart } from "@hello-pangea/dnd";
import { toast } from 'react-hot-toast';
import KanbanColumn from "./KanbanColumn";
import KanbanHeader from "./KanbanHeader";
import KanbanControls from "./KanbanControls";
import AddTaskModal from "./AddTaskModal";

interface KanbanTask {
  id: { $oid: string } | string;
  title: string;
  description: string;
  priority: string;
  dueDate: { $date: string } | null;
  completed: boolean;
  createdAt: { $date: string };
}

interface Column {
  id: string;
  title: string;
  tasks: KanbanTask[];
}

interface KanbanBoard {
  _id: { $oid: string };
  title: string;
  userId: { $oid: string };
  relatedTrack: { $oid: string } | null;
  columns: Column[];
  createdAt: { $date: string };
  updatedAt: { $date: string };
}

export default function KanbanBoard() {
  const [board, setBoard] = useState<KanbanBoard | null>(null);
  const [filteredBoard, setFilteredBoard] = useState<KanbanBoard | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [priority, setPriority] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [showCompleted, setShowCompleted] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [isFirstVisit, setIsFirstVisit] = useState(true);
  const boardRef = useRef<HTMLDivElement>(null);

  const userId = "64cfa723a2b4c83b8c4e2a00";

  const handleError = (error: any, fallbackMessage: string) => {
    const errorMessage = error?.message || fallbackMessage;
    toast.error(errorMessage, {
      duration: 3000,
      position: 'bottom-right',
    });
    console.error(errorMessage, error);
  };

  const handleSuccess = (message: string) => {
    toast.success(message, {
      duration: 2000,
      position: 'bottom-right',
    });
  };

  useEffect(() => {
    const fetchBoard = async () => {
      try {
        const res = await fetch(`/api/kanban?userId=${userId}`);
        const data = await res.json();
        if (res.ok) {
          setBoard(data);
          setFilteredBoard(data);
          localStorage.setItem("kanbanBoard", JSON.stringify(data));
        } else {
          setError(data.error || "Failed to fetch Kanban board");
        }
      } catch (err) {
        setError("Error fetching Kanban board");
        const cachedBoard = localStorage.getItem("kanbanBoard");
        if (cachedBoard) {
          setBoard(JSON.parse(cachedBoard));
          setFilteredBoard(JSON.parse(cachedBoard));
        }
      } finally {
        setLoading(false);
      }
    };

    fetchBoard();
  }, [userId]);

  useEffect(() => {
    if (!board) return;

    let filteredColumns = board.columns.map((column) => ({
      ...column,
      tasks: [...column.tasks],
    }));

    // Apply filters
    filteredColumns = filteredColumns.map((column) => ({
      ...column,
      tasks: column.tasks.filter((task) => {
        // Search filter
        const matchesSearch = !searchQuery || 
          task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          task.description?.toLowerCase().includes(searchQuery.toLowerCase());

        // Priority filter
        const matchesPriority = !priority || task.priority === priority;

        // Due date filter
        let matchesDueDate = true;
        if (dueDate) {
          const today = new Date();
          const taskDate = task.dueDate ? new Date(task.dueDate.$date) : null;
          
          if (dueDate === 'today') {
            matchesDueDate = taskDate?.toDateString() === today.toDateString();
          } else if (dueDate === 'week') {
            const weekFromNow = new Date(today);
            weekFromNow.setDate(today.getDate() + 7);
            matchesDueDate = taskDate ? taskDate <= weekFromNow : false;
          } else if (dueDate === 'overdue') {
            matchesDueDate = taskDate ? taskDate < today : false;
          }
        }

        // Completed filter
        const matchesCompleted = showCompleted || !task.completed;

        return matchesSearch && matchesPriority && matchesDueDate && matchesCompleted;
      }),
    }));

    setFilteredBoard({ ...board, columns: filteredColumns });
  }, [board, searchQuery, priority, dueDate, showCompleted]);

  // Center the columns on initial load
  useEffect(() => {
    const centerColumns = () => {
      const container = boardRef.current;
      if (!container || !filteredBoard?.columns.length) return;

      const containerWidth = container.clientWidth;
      const totalColumnsWidth =
        filteredBoard.columns.length * 320 + // Each column is w-80 (320px)
        (filteredBoard.columns.length - 1) * 24; // gap-6 (24px) between columns

      // Calculate the scroll position to center the columns
      const scrollPosition = (totalColumnsWidth - containerWidth) / 2;
      container.scrollLeft = Math.max(0, scrollPosition);
    };

    centerColumns();

    // Recenter on window resize
    window.addEventListener("resize", centerColumns);
    return () => window.removeEventListener("resize", centerColumns);
  }, [filteredBoard]);

  const fetchBoard = async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/kanban?userId=${userId}`);
      const data = await res.json();
      
      if (!res.ok) throw new Error(data.error || 'Failed to fetch board');
      
      setBoard(data);
      setFilteredBoard(data);
      localStorage.setItem("kanbanBoard", JSON.stringify(data));
    } catch (err) {
      handleError(err, "Error loading board");
      const cachedBoard = localStorage.getItem("kanbanBoard");
      if (cachedBoard) {
        setBoard(JSON.parse(cachedBoard));
        setFilteredBoard(JSON.parse(cachedBoard));
        toast.success("Loaded from cache", { icon: '📋' });
      }
    } finally {
      setLoading(false);
    }
  };

  const onDragStart = (start: DragStart) => {
    const scrollContainer = boardRef.current;
    if (!scrollContainer) return;

    const scrollSpeed = 10;
    let scrollInterval: NodeJS.Timeout;

    const handleMouseMove = (e: MouseEvent) => {
      const { clientX } = e;
      const containerRect = scrollContainer.getBoundingClientRect();

      if (clientX < containerRect.left + 50) {
        clearInterval(scrollInterval);
        scrollInterval = setInterval(() => {
          scrollContainer.scrollLeft -= scrollSpeed;
        }, 20);
      } else if (clientX > containerRect.right - 50) {
        clearInterval(scrollInterval);
        scrollInterval = setInterval(() => {
          scrollContainer.scrollLeft += scrollSpeed;
        }, 20);
      } else {
        clearInterval(scrollInterval);
      }
    };

    const handleDragEnd = () => {
      clearInterval(scrollInterval);
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleDragEnd);
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleDragEnd);
  };

  const onDragEnd = async (result: DropResult) => {
    const { source, destination } = result;
    if (!destination || !board) return;

    try {
      setIsUpdating(true);
      const res = await fetch("/api/kanban", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          taskId: result.draggableId,
          sourceColumnId: source.droppableId,
          destinationColumnId: destination.droppableId,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      await fetchBoard();
      handleSuccess("Task moved successfully");
    } catch (err) {
      handleError(err, "Failed to move task");
    } finally {
      setIsUpdating(false);
    }
  };

  useEffect(() => {
    const hasVisited = localStorage.getItem("hasVisitedKanban");
    if (!hasVisited) {
      setIsFirstVisit(true);
      localStorage.setItem("hasVisitedKanban", "true");
    } else {
      setIsFirstVisit(false);
    }
  }, []);

  const handleWelcomeClose = useCallback(() => {
    setIsFirstVisit(false);
    setIsAddModalOpen(true);
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
          <span className="text-slate-300 font-medium">Loading your board...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4 text-red-400">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Animated background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-gradient-to-br from-blue-500/10 to-transparent rounded-full blur-3xl animate-drift" />
        <div className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-gradient-to-br from-purple-500/10 to-transparent rounded-full blur-3xl animate-drift-slow" />
      </div>

      <div className="relative p-4 md:p-8 w-full max-w-[1800px] mx-auto h-[calc(100vh-2rem)]">
        <div className="rounded-2xl bg-slate-900/50 backdrop-blur-xl border border-white/5 shadow-2xl h-full flex flex-col">
          {/* Sticky header */}
          <div className="sticky top-0 z-10 bg-slate-900/95 backdrop-blur-sm border-b border-white/5 rounded-t-2xl px-6 py-4">
            <KanbanHeader title={board?.title || "My Kanban Board"} />
            <KanbanControls
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              onAddTask={() => setIsAddModalOpen(true)}
              totalTasks={board?.columns.reduce((acc, col) => acc + col.tasks.length, 0) || 0}
              priority={priority}
              setPriority={setPriority}
              dueDate={dueDate}
              setDueDate={setDueDate}
              showCompleted={showCompleted}
              setShowCompleted={setShowCompleted}
            />
          </div>

          <DragDropContext onDragStart={onDragStart} onDragEnd={onDragEnd}>
            {(!filteredBoard?.columns.length || filteredBoard.columns.every(col => !col.tasks.length)) ? (
              <div className="flex-1 grid place-items-center">
                <div className="flex flex-col items-center justify-center p-8 rounded-2xl bg-slate-800/50 backdrop-blur-sm max-w-md mx-auto text-center">
                  <svg className="w-16 h-16 mb-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                  </svg>
                  <p className="text-2xl font-semibold text-slate-300 mb-2">No tasks found</p>
                  <p className="text-sm text-slate-400 mb-6">Get started by adding your first task</p>
                  <button
                    onClick={() => setIsAddModalOpen(true)}
                    className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-all duration-200 transform hover:-translate-y-0.5 shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30"
                  >
                    Add Your First Task
                  </button>
                </div>
              </div>
            ) : (
              <div ref={boardRef} className="flex-1 flex justify-start items-start gap-6 p-6 overflow-x-auto scrollbar-thin scrollbar-thumb-blue-500/20 scrollbar-track-slate-800/50 scroll-smooth transition-all duration-300 ease-in-out">
                {filteredBoard?.columns.map((column) => (
                  <KanbanColumn
                    key={column.id}
                    column={column}
                    fetchBoard={fetchBoard}
                    userId={userId}
                    onError={handleError}
                    onSuccess={handleSuccess}
                  />
                ))}
              </div>
            )}
          </DragDropContext>
        </div>

        {/* Welcome Modal */}
        {isFirstVisit ? (
          <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl">
              <h2 className="text-2xl font-bold text-white mb-4">Welcome to your Kanban Board!</h2>
              <p className="text-slate-300 mb-6">
                Get started by creating your first task. You can organize tasks by dragging them between columns.
              </p>
              <button
                onClick={handleWelcomeClose}
                className="w-full px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-all duration-200 transform hover:-translate-y-0.5 shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30"
              >
                Get Started
              </button>
            </div>
          </div>
        ) : (
          <AddTaskModal
            isOpen={isAddModalOpen}
            onClose={() => setIsAddModalOpen(false)}
            userId={userId}
            columnId="todo" // Add default column ID
            onTaskAdded={async (newTask) => {
              try {
                const res = await fetch("/api/kanban", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    userId,
                    columnId: "todo",
                    ...newTask
                  }),
                });

                const data = await res.json();
                if (!res.ok) throw new Error(data.error);

                await fetchBoard();
                handleSuccess("Task added successfully");
                setIsAddModalOpen(false);
              } catch (err) {
                handleError(err, "Failed to add task");
              }
            }}
          />
        )}

        {/* Animations */}
        <style jsx global>{`
          @keyframes drift {
            0%, 100% { transform: translate(0, 0) rotate(0deg); }
            50% { transform: translate(2%, 2%) rotate(5deg); }
          }
          @keyframes drift-slow {
            0%, 100% { transform: translate(0, 0) rotate(0deg); }
            50% { transform: translate(-2%, -2%) rotate(-5deg); }
          }
          .animate-drift {
            animation: drift 20s ease-in-out infinite;
          }
          .animate-drift-slow {
            animation: drift-slow 25s ease-in-out infinite;
          }
          ::-webkit-scrollbar {
            height: 8px;
            width: 8px;
          }
          ::-webkit-scrollbar-track {
            background: rgba(30, 41, 59, 0.5);
            border-radius: 4px;
          }
          ::-webkit-scrollbar-thumb {
            background: rgba(59, 130, 246, 0.2);
            border-radius: 4px;
          }
          ::-webkit-scrollbar-thumb:hover {
            background: rgba(59, 130, 246, 0.4);
          }
        `}</style>
      </div>
    </div>
  );
}