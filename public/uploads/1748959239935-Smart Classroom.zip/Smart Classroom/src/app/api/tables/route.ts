import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { connectToDatabase } from "@/lib/mongodb";
import { mkdir, writeFile } from "fs/promises";
import path from "path";

export async function POST(req: NextRequest) {
  try {
    console.log("POST /api/tables: Starting request handling...");

    // Get the session
    const session = await getServerSession(authOptions);
    if (!session || !session.user?.id) {
      console.log("POST /api/tables: User not authenticated");
      return NextResponse.json({ message: "User not authenticated" }, { status: 401 });
    }

    const userId = session.user.id;
    console.log("POST /api/tables: Using userId from session", userId);

    const { db } = await connectToDatabase("learning_platform");
    console.log("POST /api/tables: Connected to database");

    const formData = await req.formData();
    const title = formData.get("title") as string;
    const content = formData.get("content") as string;
    const tags = formData.get("tags") as string;
    const files = formData.getAll("files") as File[];
    console.log("POST /api/tables: Form data parsed", { title, content, tags, hasFiles: files.length > 0 });

    if (!title || !content) {
      console.log("POST /api/tables: Missing title or content");
      return NextResponse.json({ message: "Title and content are required" }, { status: 400 });
    }

    const attachments: { filename: string; url: string; type: string }[] = [];
    if (files && files.length > 0) {
      console.log("POST /api/tables: Processing file uploads", files.map((file) => file.name));
      const uploadDir = path.join(process.cwd(), "public/uploads");
      await mkdir(uploadDir, { recursive: true }); // Ensure directory exists

      const validFiles = files.filter((file) => file.size > 0);
      if (validFiles.length > 5) {
        console.log("POST /api/tables: Too many files");
        return NextResponse.json({ message: "Maximum 5 attachments allowed" }, { status: 400 });
      }

      for (const file of validFiles) {
        const bytes = await file.arrayBuffer();
        const buffer = Buffer.from(bytes);
        const filename = `${Date.now()}-${file.name}`;
        const filePath = path.join(uploadDir, filename);
        console.log("POST /api/tables: Saving file to", filePath);
        await writeFile(filePath, buffer);
        const url = `/uploads/${filename}`;
        attachments.push({ filename: file.name, url, type: file.type });
        console.log("POST /api/tables: File saved successfully", { filename: file.name, url });
      }
    }

    const note = {
      title,
      content,
      createdBy: session.user.name || "Anonymous", // Display name
      createdById: userId, // Store as string to match session.user.id
      tags: tags ? tags.split(",").map((tag) => tag.trim()).filter((tag) => tag.length > 0) : [],
      attachments,
      ratings: [],
      averageRating: 0,
      comments: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      isPublic: true,
    };
    console.log("POST /api/tables: Note object prepared", note);

    const result = await db.collection("Notes").insertOne(note);
    console.log("POST /api/tables: Note inserted", result.insertedId);

    const insertedNote = await db.collection("Notes").findOne({ _id: result.insertedId });
    console.log("POST /api/tables: Fetched inserted note", insertedNote);

    if (!insertedNote) {
      console.error("POST /api/tables: Failed to fetch inserted note", result.insertedId);
      return NextResponse.json({ message: "Failed to fetch inserted note" }, { status: 500 });
    }

    console.log("POST /api/tables: Returning response");
    return NextResponse.json(insertedNote, { status: 201 });
  } catch (error: any) {
    console.error("Error in POST handler:", error);
    return NextResponse.json({ message: "Server error", error: error.message }, { status: 500 });
  }
}

export async function GET() {
  try {
    console.log("GET /api/tables: Starting request handling...");
    const { db } = await connectToDatabase("learning_platform");
    console.log("GET /api/tables: Connected to database");

    const notes = await db.collection("Notes").find({ isPublic: true }).toArray();

    console.log("GET /api/tables: Fetched notes successfully", notes.length);
    return NextResponse.json(notes, { status: 200 });
  } catch (error: any) {
    console.error("Error fetching notes:", error);
    return NextResponse.json({ message: "Server error while fetching notes", error: error.message }, { status: 500 });
  }
}