import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { connectToDatabase } from "@/lib/mongodb";
import { ObjectId } from "mongodb";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user?.id) {
    return NextResponse.json({ message: "User not authenticated" }, { status: 401 });
  }

  const userId = session.user.id;
  const noteId = params.id;

  if (!noteId || !ObjectId.isValid(noteId)) {
    return NextResponse.json({ message: "Invalid note ID" }, { status: 400 });
  }

  const { comment } = await req.json();
  if (!comment || typeof comment !== "string" || comment.trim().length === 0) {
    return NextResponse.json({ message: "Comment cannot be empty" }, { status: 400 });
  }

  const { db } = await connectToDatabase("learning_platform");
  const note = await db.collection("Notes").findOne({ _id: new ObjectId(noteId) });

  if (!note) {
    return NextResponse.json({ message: "Note not found" }, { status: 404 });
  }

  const newComment = {
    userId,
    comment: comment.trim(),
    createdAt: new Date().toISOString(),
  };

  const result = await db.collection("Notes").updateOne(
    { _id: new ObjectId(noteId) },
    {
      $push: { comments: newComment },
    }
  );

  if (result.modifiedCount === 0) {
    return NextResponse.json({ message: "Failed to add comment" }, { status: 500 });
  }

  const updatedNote = await db.collection("Notes").findOne({ _id: new ObjectId(noteId) });
  return NextResponse.json(updatedNote, { status: 200 });
}