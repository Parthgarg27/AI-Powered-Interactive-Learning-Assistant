import { NextRequest, NextResponse } from "next/server";
import { MongoClient, ObjectId } from "mongodb";

const uri = process.env.MONGODB_URI || "mongodb://localhost:27017";
const client = new MongoClient(uri);

async function connectToDatabase() {
  try {
    await client.connect();
    const db = client.db("learning_platform");
    return db.collection("Kanban");
  } catch (error) {
    console.error("Error connecting to MongoDB:", error);
    throw new Error("Failed to connect to the database");
  }
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 });
    }

    const collection = await connectToDatabase();
    let kanbanBoard = await collection.findOne({
      $or: [{ userId: new ObjectId(userId) }, { userId: userId }],
    });

    if (!kanbanBoard) {
      const defaultBoard = {
        title: "My Kanban Board",
        userId: userId,
        relatedTrack: null,
        columns: [
          { id: "todo", title: "To-Do", tasks: [] },
          { id: "inprogress", title: "In Progress", tasks: [] },
          { id: "completed", title: "Completed", tasks: [] },
        ],
        createdAt: { $date: new Date().toISOString() },
        updatedAt: { $date: new Date().toISOString() },
      };

      const result = await collection.insertOne(defaultBoard);
      if (!result.insertedId) {
        return NextResponse.json({ error: "Failed to create Kanban board" }, { status: 500 });
      }

      kanbanBoard = await collection.findOne({ _id: result.insertedId });
    }

    if (!kanbanBoard) {
      return NextResponse.json({ error: "Kanban board not found" }, { status: 404 });
    }

    return NextResponse.json(kanbanBoard, { status: 200 });
  } catch (error) {
    console.error("Error fetching Kanban board:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { userId, columnId, title, description, priority, dueDate } = await req.json();

    if (!userId || !columnId || !title) {
      return NextResponse.json({ error: "User ID, column ID, and title are required" }, { status: 400 });
    }

    const collection = await connectToDatabase();
    const kanbanBoard = await collection.findOne({
      $or: [{ userId: new ObjectId(userId) }, { userId: userId }],
    });

    if (!kanbanBoard) {
      return NextResponse.json({ error: "Kanban board not found" }, { status: 404 });
    }

    if (!Array.isArray(kanbanBoard.columns)) {
      return NextResponse.json({ error: "Invalid Kanban board structure: columns must be an array" }, { status: 500 });
    }

    const targetColumn = kanbanBoard.columns.find((column: any) => column.id === columnId);
    if (!targetColumn) {
      return NextResponse.json({ error: "Column not found" }, { status: 400 });
    }

    const newTask = {
      id: new ObjectId(),
      title,
      description: description || "",
      priority: priority || "low",
      dueDate: dueDate ? { $date: new Date(dueDate).toISOString() } : null,
      completed: false,
      createdAt: { $date: new Date().toISOString() },
      columnId, // Add columnId to task
    };

    const updatedColumns = kanbanBoard.columns.map((column: any) => {
      if (column.id === columnId) {
        return { ...column, tasks: [...column.tasks, newTask] };
      }
      return column;
    });

    const result = await collection.updateOne(
      { _id: kanbanBoard._id },
      {
        $set: {
          columns: updatedColumns,
          updatedAt: { $date: new Date().toISOString() },
        },
      }
    );

    if (result.modifiedCount === 0) {
      return NextResponse.json({ error: "Failed to add task" }, { status: 500 });
    }

    return NextResponse.json(
      {
        message: "Task added successfully",
        task: newTask,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error adding task:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const { userId, taskId, sourceColumnId, destinationColumnId } = await req.json();

    if (!userId || !taskId || !sourceColumnId || !destinationColumnId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const collection = await connectToDatabase();
    const kanbanBoard = await collection.findOne({
      $or: [{ userId: new ObjectId(userId) }, { userId: userId }],
    });

    if (!kanbanBoard) {
      return NextResponse.json({ error: "Kanban board not found" }, { status: 404 });
    }

    let taskToMove: any = null;
    const sourceColumn = kanbanBoard.columns.find((col: any) => col.id === sourceColumnId);
    if (sourceColumn) {
      taskToMove = sourceColumn.tasks.find((task: any) =>
        (typeof task.id === "string" ? task.id : task.id.$oid) === taskId
      );
    }

    if (!taskToMove) {
      return NextResponse.json({ error: "Task not found" }, { status: 404 });
    }

    const updatedColumns = kanbanBoard.columns.map((column: any) => {
      if (column.id === sourceColumnId) {
        return {
          ...column,
          tasks: column.tasks.filter((task: any) =>
            (typeof task.id === "string" ? task.id : task.id.$oid) !== taskId
          ),
        };
      }
      if (column.id === destinationColumnId) {
        return {
          ...column,
          tasks: [...column.tasks, taskToMove],
        };
      }
      return column;
    });

    const result = await collection.updateOne(
      { _id: kanbanBoard._id },
      {
        $set: {
          columns: updatedColumns,
          updatedAt: { $date: new Date().toISOString() },
        },
      }
    );

    if (result.modifiedCount === 0) {
      return NextResponse.json({ error: "Failed to update task position" }, { status: 500 });
    }

    return NextResponse.json({ message: "Task position updated successfully" }, { status: 200 });
  } catch (error) {
    console.error("Error updating task position:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const { userId, taskId, columnId, title, description, priority, dueDate } = await req.json();

    if (!userId || !taskId || !columnId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const collection = await connectToDatabase();
    
    // Convert taskId to match possible formats in database
    const taskIdCondition = { $in: [taskId, { $oid: taskId }] };

    // Format date properly if it exists
    const formattedDueDate = dueDate ? { $date: new Date(dueDate).toISOString() } : null;

    const updateQuery = {
      userId,
      "columns.id": columnId,
    };

    const updateData = {
      $set: {
        "columns.$[column].tasks.$[task].title": title,
        "columns.$[column].tasks.$[task].description": description,
        "columns.$[column].tasks.$[task].priority": priority,
        "columns.$[column].tasks.$[task].dueDate": formattedDueDate,
        "columns.$[column].tasks.$[task].updatedAt": { $date: new Date().toISOString() }
      }
    };

    const options = {
      arrayFilters: [
        { "column.id": columnId },
        { "task.id": taskIdCondition }
      ]
    };

    const result = await collection.updateOne(updateQuery, updateData, options);

    if (result.matchedCount === 0) {
      return NextResponse.json({ error: "Task not found" }, { status: 404 });
    }

    if (result.modifiedCount === 0) {
      return NextResponse.json({ error: "No changes made to the task" }, { status: 400 });
    }

    return NextResponse.json({ message: "Task updated successfully" });
  } catch (error) {
    console.error("Error updating task:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const body = await req.json();
    const { userId, taskId, columnId } = body;

    if (!userId || !taskId || !columnId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const collection = await connectToDatabase();
    
    const result = await collection.updateOne(
      { 
        userId: userId,
        "columns.id": columnId 
      },
      { 
        $pull: { 
          "columns.$.tasks": {
            "id": { $in: [taskId, { $oid: taskId }] }
          }
        }
      }
    );

    if (result.modifiedCount === 0) {
      return NextResponse.json({ error: "Failed to delete task" }, { status: 404 });
    }

    return NextResponse.json({ message: "Task deleted successfully" });
  } catch (error) {
    console.error("Error deleting task:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}